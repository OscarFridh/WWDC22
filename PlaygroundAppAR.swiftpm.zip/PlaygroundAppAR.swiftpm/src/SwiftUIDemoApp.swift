//
//  SwiftUIDemoApp.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import SwiftUI

@main
struct SwiftUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
