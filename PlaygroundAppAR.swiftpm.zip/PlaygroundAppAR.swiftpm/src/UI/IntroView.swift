//
//  IntroView.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI

struct IntroView: View {
    var clickedNext: (() -> ())?
    
    var body: some View {
        VStack(spacing: 50) {
                        
            Text("Hello!")
                .font(.largeTitle)
            
            VStack {
                
                HStack {
                    Image("oscar_hello")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxHeight: 200)
                    
                    Image("jessica_hello")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxHeight: 200)
                }
                
                
                Text("This is Oscar and Jessica. They are happy together but they see the world differently. Jessica is short-sighted so everything is blurry for her. Let's have a closer look in AR to get a better understanding of what it's like.")
                
            }
            
            ButtonBridge(title: "Continue") {
                clickedNext?()
            }
            .frame(height: 50)

        }
        .frame(maxWidth: 600)
    }
}

/*
struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
    }
}
*/
