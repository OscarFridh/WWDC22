//
//  PersonOverlayView.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import SwiftUI


struct PersonOverlayView: View {
    @Binding var boySelected: Bool
    var jessicaImageName: String = "jessica_blur"
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Button {
                    boySelected = true
                } label: {
                    PersonButtonView(imageName: "oscar_hello", selected: boySelected)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(20))
                        .offset(x: -50, y: 50)
                        .scaleEffect(boySelected ? 1 : 0.7, anchor: .bottomLeading)
                }


                Spacer()
                
                Button {
                    boySelected = false
                } label: {
                    PersonButtonView(imageName: jessicaImageName, selected: !boySelected)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(-20))
                        .offset(x: 50, y: 50)
                        .scaleEffect(boySelected ? 0.7 : 1, anchor: .bottomTrailing)
                }
            }
            .animation(.default, value: boySelected)
        }
        .ignoresSafeArea()
    }
}

struct PersonOverlayView2: View {
    @Binding var state: GlassesState
    
    var boySelected: Bool {
        state == .oscar
    }
    
    var jessicaImageName: String {
        switch state {
        case .oscar, .jessica(nil):
            return "jessica_blur"
        case .jessica(0):
            return "jessica_bad"
        case .jessica(1), .jessica(3):
            return "jessica_ok"
        case .jessica(2):
            return "jessica_happy"
        default:
            return "jessica_blur"
        }
    }
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Button {
                    state = GlassesState.oscar
                } label: {
                    PersonButtonView(imageName: "oscar_hello", selected: boySelected)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(20))
                        .offset(x: -50, y: 50)
                        .scaleEffect(boySelected ? 1 : 0.7, anchor: .bottomLeading)
                }


                Spacer()
                
                Button {
                    if state == .oscar {
                        state = GlassesState.jessica(nil)
                    }
                } label: {
                    PersonButtonView(imageName: jessicaImageName, selected: !boySelected)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(-20))
                        .offset(x: 50, y: 50)
                        .scaleEffect(boySelected ? 0.7 : 1, anchor: .bottomTrailing)
                }
            }
            .animation(.default, value: state)
        }
        .ignoresSafeArea()
    }
}

/*
struct PersonOverlayView_Previews: PreviewProvider {
    
    static var previews: some View {
        Container()
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
    }
    
    struct Container: View {
        @State private var boySelected = true
        
        var body: some View {
            PersonOverlayView(boySelected: $boySelected)
        }
    }
}
*/
