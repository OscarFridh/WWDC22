//
//  TaskView.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI


struct TaskView: View {
    var nextAction: NextAction?
    @State private var focusSlide: Float = 0
    
    // Så här får det vara så länge, hade lite problem med onChange(of:)...
    var completedTask: Bool {
        target - okRange < focusSlide && focusSlide < target + okRange
    }
    
    var imageBlur: CGFloat {
        CGFloat(abs(target - focusSlide))
    }
    
    private let target: Float = -8.36
    private let okRange: Float = 0.5
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            
            Text("Short-sightedness, also called near-sightedness and myopia, means that the eye focuses the light in front, instead of on the retina. This causes distant object to appear blurry while close objects appear normal.")
                .padding(.bottom, 50)
            
            HStack {
                Image("syntavla")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .blur(radius: imageBlur)
                
                Spacer()
                
                LightSimulationView(value: focusSlide/10)
            }
            .frame(height: 200)
            .padding(.bottom, 50)
            
            Text("This can be fixed by adding a lens in front of the eye that adjusts the light so that the focus point can be moved back to the retina.")
            
            VStack() {
                Slider(value: $focusSlide, in: -10...10)
                Text("\(focusSlide)")
            }


            VStack(alignment: .leading) {
                Text("Good job!")
                Text("Now let's help Jessica pick the right glasses!")
                Text("Please place the glasses on a table nearby in the next AR view")
            }
            .opacity(completedTask ? 1 : 0)
            .padding(.bottom, 50)
            
            
            ButtonBridge {
                nextAction?()
            }
            .frame(height: 50)
            .opacity(completedTask ? 1 : 0)
            
            
        }
        .animation(.default, value: completedTask)
        .frame(maxWidth: 600)
        
    }
}

struct LenseView: View {
    var value: Float = 0
    
    var body: some View {
        GeometryReader { gr in
            Path { path in
                
                let offset = -CGFloat(value) * gr.size.width/2
                
                path.move(to: .zero)
                //path.addLine(to: CGPoint(x: 0, y: gr.size.height))
                path.addCurve(
                    to: CGPoint(x: 0, y: gr.size.height),
                    control1: CGPoint(x: offset, y: gr.size.height/2),
                    control2: CGPoint(x: offset, y: gr.size.height/2)
                )
                
                path.addLine(to: CGPoint(x: gr.size.width, y: gr.size.height))
                
                path.addCurve(
                    to: CGPoint(x: gr.size.width, y: 0),
                    control1: CGPoint(x: gr.size.width - offset, y: gr.size.height/2),
                    control2: CGPoint(x: gr.size.width - offset, y: gr.size.height/2)
                )
                
                path.closeSubpath()
            }
        }
    }
}

struct LightSimulationView: View {
    var value: Float
    
    var body: some View {
        HStack {
            LenseView(value: value)
                .foregroundColor(.blue)
                .frame(width: 20, height: 200)
            
            Spacer()
            
            Image("eye")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 200)
        }
        .frame(width: 300)
        .overlay {
            // Light rays
            GeometryReader { gr in
                Path { path in
                    let lenseGap: CGFloat = 15
                    let eyeX: CGFloat = 70
                    let eyeGap: CGFloat = -10 * CGFloat(value)
                    let focusX: CGFloat = 200 - CGFloat(value) * 95
                    
                    path.move(to: CGPoint(x: -100, y: gr.size.height/2 - lenseGap))
                    path.addLine(to: CGPoint(x: 0, y: gr.size.height/2 - lenseGap))
                    path.addLine(to: CGPoint(x: eyeX, y: gr.size.height/2 - lenseGap - eyeGap))
                    path.addLine(to: CGPoint(x: focusX, y: gr.size.height/2))
                    
                    
                    path.move(to: CGPoint(x: -100, y: gr.size.height/2 + lenseGap))
                    path.addLine(to: CGPoint(x: 0, y: gr.size.height/2 + lenseGap))
                    path.addLine(to: CGPoint(x: eyeX, y: gr.size.height/2 + lenseGap + eyeGap))
                    path.addLine(to: CGPoint(x: focusX, y: gr.size.height/2))
                    
                }
                .stroke(.yellow, lineWidth: 3)
            }
        }
    }
}

/*
struct TaskView_Previews: PreviewProvider {
    static var previews: some View {
        TaskView()
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
    }
}
*/
