//
//  PersonOverlayViewSlider.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI


struct PersonOverlayViewSlider: View {
    
    /// A value between 0-1
    @Binding var blur: Double
    let showSlider: Bool
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                Button {
                    blur = 0
                } label: {
                    PersonButtonView(imageName: "oscar_hello", selected: blur < 0.5)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(20))
                        .offset(x: -50, y: 50)
                        .scaleEffect(1 - blur * 0.3, anchor: .bottomLeading)
                }

                Slider(value: $blur, in: 0...1)
                    .opacity(showSlider ? 1 : 0)
                
                Button {
                    blur = 1
                } label: {
                    PersonButtonView(imageName: "jessica_blur", selected: blur > 0.5)
                        .frame(maxWidth: 300, maxHeight: 300)
                        .rotationEffect(.degrees(-20))
                        .offset(x: 50, y: 50)
                        .scaleEffect(0.7 + blur * 0.3, anchor: .bottomTrailing)
                }
            }
            .animation(.default, value: blur)
        }
        .ignoresSafeArea()
    }
}



/*
struct PersonOverlayViewSlider_Previews: PreviewProvider {
    
    static var previews: some View {
        Container()
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
    }
    
    struct Container: View {
        @State private var boySelected = true
        
        var body: some View {
            PersonOverlayViewSlider(blur: .constant(0.3), showSlider: true)
        }
    }
}
*/
