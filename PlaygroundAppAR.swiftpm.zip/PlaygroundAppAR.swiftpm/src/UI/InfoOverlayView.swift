//
//  InfoOverlayView.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI

struct InfoOverlayView: View {
    var nextAction: NextAction?
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                
                Button {
                    nextAction?()
                } label: {
                    
                    // TODO: Show info if time allows
                    // Label("Instructions", systemImage: "info.circle")
                    
                    Text("Next page")
                        .padding()
                        .background(.thinMaterial)
                        .cornerRadius(5)
                }
            }
            .padding()
            Spacer()
        }
    }
}

/*
struct InfoOverlayView_Previews: PreviewProvider {
    static var previews: some View {
        InfoOverlayView()
    }
}
*/
