//
//  PersonButtonView.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI

struct PersonButtonView: View {
    let imageName: String
    let selected: Bool
    
    var body: some View {
        GeometryReader { g in
            let s = min(g.size.height, g.size.width) * 0.8
            ZStack {
                Circle()
                    .foregroundColor(selected ? .orange : .gray)
                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: s, height: s)
                    .animation(.default, value: imageName)
            }
            .opacity(selected ? 1 : 0.5)
        }
    }
}
