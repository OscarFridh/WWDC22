//
//  OutroView.swift
//  StoryDemo
//
//  Created by Oscar Fridh on 2022-04-24.
//

import SwiftUI

struct OutroView: View {
    var body: some View {
        
        VStack {
            
            Text("Thank you!")
                .font(.largeTitle)
            
            VStack {
                                
                HStack {
                    Image("oscar_bye")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxHeight: 200)
                    
                    Image("jessica_happy")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxHeight: 200)
                }
                
                // TODO: Finslipa den här texten
                Text("Thanks to your help Jessica can now see as clearly as Oscar. I hope you have enjoyed this experience and that it has brought more understanding about what it's like to have blurry vision.")
            }
        }
        .frame(maxWidth: 600)
    }
}

/*
struct OutroView_Previews: PreviewProvider {
    static var previews: some View {
        OutroView()
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
    }
}
*/
