//
//  GlassesViewController.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-23.
//


import Combine
import RealityKit
import UIKit

// TODO: Kapsla in blur, så att jag har alla settings samlade på ett ställe i en modell?

protocol GlassesViewControllerDelegate: AnyObject {
    func didWearGlasses(_ index: Int)
    func didPutGlassesDown()
}

class GlassesViewController: ARViewControllerBase {
    
    var state: GlassesState! {
        didSet {
            guard state != oldValue else { return }
            switch state {
            case .oscar:
                currentGlasses?.putDown()
                sigma = 0
            default:
                sigma = noGlassesBlur
                // Since Oscar cannot wear glasses we don't need to do anything more
            }
        }
    }
    
    var oscarSelected: Bool {
        state == .oscar
    }
    
/*
    var oscarSelected: Bool = false {
        didSet {
            guard oscarSelected != oldValue else { return }
            if oscarSelected {
                currentGlasses?.putDown()
                sigma = 0
            } else {
                sigma = noGlassesBlur
                // Since Oscar cannot wear glasses we don't need to do anything more
            }
        }
    }
 */
    
    weak var delegate: GlassesViewControllerDelegate?
    
    private var cameraAnchor: AnchorEntity!
    private var tableAnchor: AnchorEntity!
    private var subscriptions: Set<AnyCancellable> = []
    private var glassesContainers = [GlassesContainerEntity]()
    private var currentGlasses: GlassesContainerEntity? {
        glassesContainers.first { $0.pickedUp }
    }
    
    private var noGlassesBlur: Float {
        oscarSelected ? 0 : 20
    }
    private let distanceBetweenGlasses: Float = 0.25
    private let glassesBlur: [Float] = [2, 1, 0, 1].map { $0 * 6 }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initAnchors()
        
        Experience.loadGlassesAsync { [weak self] result in
            let experience = try! result.get()
            self?.addExperience(experience)
        }
        
        sigma = noGlassesBlur
        
        // Animation callbacks
        arView.scene.publisher(for: AnimationEvents.PlaybackCompleted.self)
            .filter { $0.playbackController.entity is GlassesContainerEntity }
            .sink(receiveValue: { [self] event in
                updateBlur()
            }).store(in: &subscriptions)
        
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        arView.addGestureRecognizer(tapGR)
    }
    
    private func initAnchors() {
        tableAnchor = AnchorEntity(plane: .horizontal)
        arView.scene.anchors.append(tableAnchor)
        
        cameraAnchor = AnchorEntity(.camera)
        arView.scene.addAnchor(cameraAnchor)
    }
    
    private func addExperience(_ experience: Experience.Glasses) {

        // TODO: Jämför med Jessicas riktiga glasögon för att hitta en bra storlek!
        // TODO: Se om jag kan fixa så att de hamnar rätt på ett bord...
        
        for (i, blur) in glassesBlur.enumerated() {
            let container = GlassesContainerEntity(glassesExperience: experience, blur: blur)
            glassesContainers.append(container)
            tableAnchor.addChild(container)
            
            container.position.x = Float(i) * distanceBetweenGlasses
        }
    }
    
    func updateBlur() {
        sigma = noGlassesBlur
        for container in glassesContainers {
            if container.pickedUp {
                sigma = container.blur
            }
        }
    }
    
    @objc func onTap(_ sender: UITapGestureRecognizer) {
        let tapLocation = sender.location(in: arView)
        
        if let match = arView.entity(at: tapLocation) {
            
            let container = match.parent as? GlassesContainerEntity
            let alreadyPickedUp = container?.pickedUp == true
            if alreadyPickedUp {
                return
            }
            
            for container in glassesContainers {
                if container.pickedUp && match.parent != container {
                    container.putDown()
                }
            }
            
            updateBlur()
            
            if let container = container {
                // Blur will be updated again on completion
                let index = glassesContainers.firstIndex(of: container)!
                container.pickUpTo(cameraAnchor: cameraAnchor)
                delegate?.didWearGlasses(index)
            }
            
        } else {
            currentGlasses?.putDown()
            updateBlur()
            // We didn't pick up any glasses
            delegate?.didPutGlassesDown()
        }
    }
    
    private func putDownGlasses() {
        for container in glassesContainers {
            if container.pickedUp {
                container.putDown()
            }
        }
    }
}


