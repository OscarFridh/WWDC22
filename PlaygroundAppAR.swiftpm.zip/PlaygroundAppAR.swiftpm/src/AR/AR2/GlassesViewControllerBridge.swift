//
//  GlassesViewControllerBridge.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-23.
//

import SwiftUI

enum GlassesState: Equatable {
    case oscar
    case jessica(Int?)
}

struct GlassesViewControllerBridge: UIViewControllerRepresentable {
    @Binding var state: GlassesState
    
    func makeUIViewController(context: Context) -> GlassesViewController {
        let vc = GlassesViewController()
        vc.state = state
        vc.delegate = context.coordinator
        return vc
    }
    
    
    func updateUIViewController(_ vc: GlassesViewController, context: Context) {
        vc.state = state
    }
}


extension GlassesViewControllerBridge {
    class Coordinator: NSObject, GlassesViewControllerDelegate {
        var parent: GlassesViewControllerBridge
        
        init(parent: GlassesViewControllerBridge) {
            self.parent = parent
        }
        
        func didWearGlasses(_ index: Int) {
            parent.state = .jessica(index)
        }
        
        func didPutGlassesDown() {
            parent.state = .oscar
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
}

