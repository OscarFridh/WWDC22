//
//  GlassesContainerEntity.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-23.
//

import RealityKit

class GlassesContainerEntity: Entity {
    let blur: Float
    
    private var originalTransform: Transform?
    private var originalParent: Entity?
    private let glasses: Entity
    private(set) var pickedUp = false
    private var collisionComponent: CollisionComponent
    
    private let animationDuration = 1.0
    private let distanceFromCamera: Float = 0.1
    
    
    init(glassesExperience: Experience.Glasses, blur: Float) {
        let glasses = glassesExperience.glasses!.clone(recursive: true)
        glasses.generateCollisionShapes(recursive: false)
        self.collisionComponent = glasses.components[CollisionComponent.self] as! CollisionComponent
        self.glasses = glasses
        self.blur = blur
        super.init()
        self.addChild(glasses)
    }
    
    required init() {
        fatalError("init() has not been implemented")
    }
    
    func pickUpTo(cameraAnchor: AnchorEntity) {
        guard !pickedUp else { return }
        pickedUp = true
        originalTransform = transform
        originalParent = parent
        glasses.components.remove(CollisionComponent.self)

        removeFromParent(preservingWorldTransform: true)
        cameraAnchor.addChild(self, preservingWorldTransform: true)
        
        var transform = transform
        transform.translation = SIMD3(x: 0, y: 0, z: -distanceFromCamera)
        transform.rotation = .init(angle: .pi, axis: .init(x: 0, y: 1, z: 0))
        
        move(to: transform, relativeTo: parent!, duration: animationDuration)
    }
    
    func putDown() {
        guard pickedUp else { return }
        pickedUp = false
        glasses.components.set(collisionComponent)
        
        removeFromParent(preservingWorldTransform: true)
        originalParent!.addChild(self, preservingWorldTransform: true)
        
        move(to: originalTransform!, relativeTo: parent!, duration: animationDuration)
    }
}
