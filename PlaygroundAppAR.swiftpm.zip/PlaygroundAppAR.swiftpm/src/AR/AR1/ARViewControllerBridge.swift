//
//  File.swift
//  
//
//  Created by Oscar Fridh on 2022-04-25.
//

import SwiftUI

struct ARViewControllerBridge: UIViewControllerRepresentable {
    let sigma: Float
    
    func makeUIViewController(context: Context) -> ARViewControllerBase {
        let vc = ARViewController()
        vc.sigma = sigma
        return vc
    }
    
    func updateUIViewController(_ uiViewController: ARViewControllerBase, context: Context) {
        uiViewController.sigma = sigma
    }
}
