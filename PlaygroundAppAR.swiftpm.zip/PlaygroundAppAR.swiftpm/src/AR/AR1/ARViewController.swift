//
//  File.swift
//  
//
//  Created by Oscar Fridh on 2022-04-25.
//

import RealityKit

class ARViewController: ARViewControllerBase {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let anchor = AnchorEntity(plane: .horizontal)
        arView.scene.anchors.append(anchor)
        
        Experience.loadBoxAsync(completion: { [weak self] (result) in
            let experience = try! result.get()
            let chair = experience.group as! (Entity & HasCollision)
            
            if let front = chair.findEntity(named: "chart") {
                front.isEnabled = false // Hide texture
                
                let scale: Float = 0.7
                let mesh: MeshResource = .generatePlane(width: 1.6 * scale, depth: 1.6 * scale)
                        
                var material = UnlitMaterial()
                material.color = .init(tint: .white, texture: .init(try! .load(named: "syntavlaAR.png")))

                let model = ModelEntity(mesh: mesh, materials: [material])
                front.parent!.addChild(model)
                model.transform = front.transform
            }
            
            anchor.addChild(chair)
            self?.arView.installGestures(for: chair)
        })
    }
    
    
    
}
