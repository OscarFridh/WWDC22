//
//  ARViewControllerBase.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import ARKit
import MetalPerformanceShaders
import RealityKit
import UIKit
import SwiftUI


class ARViewControllerSuper: UIViewController {
    let arView = ARView()
    
    var session: ARSession {
        arView.session
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(arView)
        arView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate(arView.pin(to: view))
        
        let coachingOverlay = ARCoachingOverlayView()
        coachingOverlay.session = session
        coachingOverlay.goal = .horizontalPlane
        arView.addSubview(coachingOverlay)
        coachingOverlay.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate(coachingOverlay.pin(to: arView))
    }
}

/// Blur using MetalPerformanceShader -- avoids jagger from SwiftUI blur modifier
class ARViewControllerBase: ARViewControllerSuper {
    var sigma: Float = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        arView.renderCallbacks.postProcess = { [weak self] context in
            self?.postEffectMPSGaussianBlur(context: context)
        }
    }

    func postEffectMPSGaussianBlur(context: ARView.PostProcessContext) {
            let gaussianBlur = MPSImageGaussianBlur(device: context.device, sigma: sigma)
            gaussianBlur.encode(commandBuffer: context.commandBuffer,
                                sourceTexture: context.sourceColorTexture,
                                destinationTexture: context.targetColorTexture)
    }
}
