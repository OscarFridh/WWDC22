//
//  ARBlurView.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import SwiftUI


/*
struct ARBlurViewNoSlider: View {
    @State private var boySelected = true
    
    var body: some View {
        ZStack {
            ARContentView(blur: boySelected ? 0 : 10)
            PersonOverlayView(boySelected: $boySelected)
        }
    }
}
 */


struct ARBlurViewSlider: View {
    @State private var blur: Double = 0
    
    var body: some View {
        ZStack {
            ARContentView(blur: CGFloat(blur) * 10)
                .animation(.default, value: blur)
            PersonOverlayViewSlider(blur: $blur, showSlider: true)
        }
    }
}

struct ARContentView: View {
    var blur: CGFloat
    var body: some View {
        ZStack {
            ARViewControllerBridge(sigma: Float(blur) * 2)
        }
    }
}
