//
//  CubeTestViewController.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import Combine
import RealityKit
import UIKit


/// Osäker på om detta funkar, endast för att testa!!!
class CubeTestViewController: ARViewControllerBase {
    private var scaleUp = true
    
    private var cameraAnchor: AnchorEntity!
    private var floorAnchor: AnchorEntity!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add anchor for floor
        floorAnchor = AnchorEntity(plane: .horizontal)
        arView.scene.anchors.append(floorAnchor)
        let anchor = floorAnchor!
        
        // Add anchor for camera
        cameraAnchor = AnchorEntity(.camera)
        arView.scene.addAnchor(cameraAnchor)
        
        addCubeExperiment(anchor: anchor)
    }
    
    func addCubeExperiment(anchor: AnchorEntity) {
        let container = Entity()
        let entity = createBox()
        container.addChild(entity)
        anchor.addChild(container)
    }
    
    func createBox() -> ModelEntity {
        let box = MeshResource.generateBox(size: 0.2)
        let material = SimpleMaterial(color: .green, isMetallic: true)
        let entity = ModelEntity(mesh: box, materials: [material])
        entity.generateCollisionShapes(recursive: true)
        return entity
    }
}


