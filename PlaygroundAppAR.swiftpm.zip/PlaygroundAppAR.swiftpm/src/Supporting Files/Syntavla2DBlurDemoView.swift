//
//  Syntavla2DBlurDemoView.swift
//  SwiftUIDemo
//
//  Created by Oscar Fridh on 2022-04-22.
//

import SwiftUI

struct Syntavla2DBlurDemoView: View {
    var body: some View {
        HStack {
            Image("syntavla")
                .resizable()
                .aspectRatio(contentMode: .fit)
            Image("syntavla")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .blur(radius: 10)
        }
    }
}

/*
struct Syntavla2DBlurDemoView_Previews: PreviewProvider {
    static var previews: some View {
        Syntavla2DBlurDemoView()
    }
}
*/
